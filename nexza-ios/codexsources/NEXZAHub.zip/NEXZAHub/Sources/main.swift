// The Swift Programming Language
// https://docs.swift.org/swift-book

// This file defines a minimal entry point for the Swift package. When
// building as an executable, it will print a simple greeting. When used
// as a library, this file can be removed without affecting the package.

print("Hello, world!")